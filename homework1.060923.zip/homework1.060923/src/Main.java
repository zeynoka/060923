public class Main {
    public static void main(String[] args) {
        double m = 500.0;
        System.out.println("Километров:" + m/1000);
        System.out.println("Миль:" + m/1600);
        System.out.println("фут:" + m/0.30);


        //а аршин как получить?


        

    }
}